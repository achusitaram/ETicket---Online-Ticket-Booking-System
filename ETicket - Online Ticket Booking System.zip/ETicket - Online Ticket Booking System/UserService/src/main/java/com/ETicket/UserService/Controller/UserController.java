package com.ETicket.UserService.Controller;

import java.util.List;
//import java.util.Optional;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ETicket.UserService.Service.UserService;
import com.ETicket.UserService.Model.UserModel;

@RestController
public class UserController {
	@Autowired
	private UserService service;

	@RequestMapping(method = RequestMethod.PUT, value = "/admin/user/updateuser/{id}")
	public ResponseEntity<UserModel> updateDetails(@PathVariable("id") String userid,
			@Valid @RequestBody UserModel user) {
		return new ResponseEntity<>(service.updateDetails(userid, user), HttpStatus.OK);
	}

	@GetMapping("/admin/allusers")
	public List<UserModel> getAllUser() {
		return service.getAllUser();
	}

	@PostMapping("/admin/newusers")
	public void addUser(@RequestBody UserModel user) {
		service.addUser(user);
	}

	@DeleteMapping(path = "/admin/user/{id}")
	public void dlt(@PathVariable String id) {
		service.dlt(id);

	}

	@RequestMapping(method = RequestMethod.POST, value = "/admin/user/login")
	public String addUser(@RequestBody com.ETicket.UserService.Model.UserLogin loginuser) {
		return service.login(loginuser);

	}

	@GetMapping(path = "/admin/user/{id}")
	public Optional<UserModel> userDetails(@PathVariable String id) {
		return service.findUser(id);
	}

}
