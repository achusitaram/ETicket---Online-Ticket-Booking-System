package com.ETicket.UserService.Repository;


import org.springframework.stereotype.Repository;

import com.ETicket.UserService.Model.UserModel;



import org.springframework.data.repository.CrudRepository;

	@Repository
	public interface UserRepository extends CrudRepository<UserModel, String> {


	}



