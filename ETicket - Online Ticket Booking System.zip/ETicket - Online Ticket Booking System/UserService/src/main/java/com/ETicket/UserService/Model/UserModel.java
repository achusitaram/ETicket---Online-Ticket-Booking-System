package com.ETicket.UserService.Model;

//import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_table", schema = "eticket")
public class UserModel{
    @Id
    
    @Column(name = "userid")
	private String userid;
    @Column(name = "username")
    private String username;
    @Column(name = "emailid")
	private String emailid;
    @Column(name = "password")
	private String password;
    @Column(name = "phonenumber")
	private Long phonenumber;
    @Column(name = "accesstype")
	private String accesstype;
    
    
	public UserModel() {
		super();
	}


	public UserModel(String userid, String username, String emailid, String password, Long phonenumber,
			String accesstype) {
		super();
		this.userid = userid;
		this.username = username;
		this.emailid = emailid;
		this.password = password;
		this.phonenumber = phonenumber;
		this.accesstype = accesstype;
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Long getPhonenumber() {
		return phonenumber;
	}


	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}


	public String getAccesstype() {
		return accesstype;
	}


	public void setAccesstype(String accesstype) {
		this.accesstype = accesstype;
	}


	@Override
	public String toString() {
		return "UserModel [userid=" + userid + ", username=" + username + ", emailid=" + emailid + ", password="
				+ password + ", phonenumber=" + phonenumber + ", accesstype=" + accesstype + "]";
	} 
    
	
}