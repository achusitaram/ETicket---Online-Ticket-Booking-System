package com.ETicket.UserService.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ETicket.UserService.Model.UserLogin;
import com.ETicket.UserService.Model.UserModel;
import com.ETicket.UserService.Repository.UserRepository;

@Service
public class UserService {

	@Autowired
	public UserRepository repo;

	public void dlt(String userid) {
		repo.deleteById(userid);
	}

	public List<UserModel> getAllUser() {
		List<UserModel> users = (List<UserModel>) repo.findAll();
		return users;
	}

	public Optional<UserModel> findUser(String userid) {
		Optional<UserModel> users = repo.findById(userid);
		return users;
	}

	public String login(UserLogin loginuser) {
		UserModel user = null;
		Optional<UserModel> optuser = repo.findById(loginuser.getUserid());

		if (optuser.isPresent()) {
			user = optuser.get();
			if (user.getPassword().equals(loginuser.getPassword())) {
				return "successfully login";
			}

			else {
				return "failed login";

			}
		} else {
			return "No user present";
		}
	}

	public void addUser(UserModel user) {
		repo.save(user);
	}

	public UserModel updateDetails(String id, UserModel user) {
		user.setUserid(id);
		return repo.save(user);
	}

}