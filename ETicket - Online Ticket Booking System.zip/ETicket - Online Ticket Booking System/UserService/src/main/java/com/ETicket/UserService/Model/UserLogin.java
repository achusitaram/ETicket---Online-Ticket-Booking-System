package com.ETicket.UserService.Model;



public class UserLogin {

	private String userid;
	private String username;
	private String emailid;
	private String password;
	private Long phonenumber;
	private String accessyype; 
	
	
	public UserLogin() {
		super();
	}
	


	public UserLogin(String userid, String username, String emailid, String password, Long phonenumber,
			String accessyype) {
		super();
		this.userid = userid;
		this.username = username;
		this.emailid = emailid;
		this.password = password;
		this.phonenumber = phonenumber;
		this.accessyype = accessyype;
	}



	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Long getPhonenumber() {
		return phonenumber;
	}


	public void setPhonenumber(Long phonenumber) {
		this.phonenumber = phonenumber;
	}


	public String getAccessyype() {
		return accessyype;
	}


	public void setAccessyype(String accessyype) {
		this.accessyype = accessyype;
	}



	@Override
	public String toString() {
		return "UserLogin [userid=" + userid + ", username=" + username + ", emailid=" + emailid + ", password="
				+ password + ", phonenumber=" + phonenumber + ", accessyype=" + accessyype + "]";
	}


}
