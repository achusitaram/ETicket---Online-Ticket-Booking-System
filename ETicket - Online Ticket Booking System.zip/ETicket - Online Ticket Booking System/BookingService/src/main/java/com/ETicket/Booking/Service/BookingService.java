package com.ETicket.Booking.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ETicket.Booking.Model.Booking;


import com.ETicket.Booking.Model.Show;

import com.ETicket.Booking.Repository.BookingRepository;

import com.ETicket.Booking.Repository.ShowRepository;

@Service
public class BookingService {

	@Autowired
	private BookingRepository bookrepo;
	@Autowired
	private ShowRepository showrepo;
	

	public List<Booking> getBookings() {
		return (List<Booking>) bookrepo.findAll();
	}


	public Booking addBooking(Booking booking) {

		Integer nooftickets = booking.getNooftickets();
		Integer showid = booking.getShow().getShowid();
		Optional<Show> show = showrepo.findById(showid);

		Float ticketcost = show.get().getTicketcost();
		Integer seatsavailable = show.get().getSeatsavailable();
		Integer remainingseats = seatsavailable - nooftickets;
		show.get().setSeatsavailable(remainingseats);
		System.out.println(remainingseats);
		System.out.println(ticketcost);
		Float cost = (nooftickets * ticketcost);
		booking.setCost(cost);

		String bmovie = String.valueOf(show.get().getMovie().getMoviename());
		booking.setMoviename(bmovie);

		String tmovie = String.valueOf(show.get().getTheatre().getTheatrename());
		booking.setMoviename(tmovie);

		booking.setShowdate(show.get().getShowdate());

		booking.setShowtime(show.get().getShowtime());
		booking.setStatus("booked");
		
	

		return bookrepo.save(booking);

	}

	public List<Show> getAllShows() {
		return (List<Show>) showrepo.findAll();
	}

	public Show addShow(Show show) {
		System.out.println(show.getMovie().getMoviename());
		return showrepo.save(show);
	}

	public Show updateshowDetails(Integer showid, Show show) {
		show.setShowid(showid);
		return showrepo.save(show);
	}

	public Show getShow(Integer showid) {
		return showrepo.findById(showid).get();
	}

	public void deleteShow(Integer showid) {
		showrepo.deleteById(showid);
	}


	public Booking deleteBooking(Integer bookingid) {

		Booking booking = getBookingbyId(bookingid);
		Integer seatsBooked = booking.getNooftickets();
		Show show = booking.getShow();
		Integer seatsAvailable = show.getSeatsavailable();
		Integer remainingSeats = (seatsAvailable - seatsBooked);
		System.out.println(remainingSeats);
		show.setSeatsavailable(remainingSeats);
		booking.setStatus("Cancelled");
		return bookrepo.save(booking);
		
	}

	private Booking getBookingbyId(Integer bookingid) {

		return bookrepo.findById(bookingid).get();
	}

	public List<Show> findShowByMoive(String moviename) {
		List<Show> allshows = getAllShows();
		List<Show> shows = new ArrayList<>();
		for (Show show : allshows) {
			if (show.getMovie().getMoviename().equals(moviename)) {
				shows.add(show);
			}
		}
		return shows;
	}

	public List<Show> findShowByTheatre(String theatrename) {
		List<Show> allshows = getAllShows();
		List<Show> shows = new ArrayList<>();
		for (Show show : allshows) {
			if (show.getTheatre().getTheatrename().equals(theatrename)) {
				shows.add(show);
			}
		}
		return shows;
	}

	// Format example: 2020-11-11T00:00:00.000+00:00/2020-12-12T00:00:00.000+00:00
	public List<Booking> getBookingsbytdate(String fromDate,String toDate) throws ParseException{
        List<Booking> allbookings= new ArrayList<>();
        List<Booking> bookinglist= new ArrayList<>();
        bookrepo.findAll().forEach(allbookings::add);

        System.out.println("from date "+ fromDate);
        System.out.println("to date "+ toDate);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date startdate = dateFormat.parse(fromDate);
        Date enddate = dateFormat.parse(toDate);
       
      
       
        for(Booking booking : allbookings){	
           if((booking.getShow().getShowdate().compareTo(startdate)) >= 0 && (booking.getShow().getShowdate().compareTo(enddate) <= 0))
        		   {
        	   			bookinglist.add(booking);
        	   			return bookinglist;
        		   }
        }
        return null;
       
    }



		public List<Booking> getBookingsbyuser(String userid) {
			List<Booking> booking = getBookings();
			List<Booking> bookng = new ArrayList<>();
			for (Booking bookn : booking) {
				if (bookn.getUser().getUserid().equals(userid)) {
					bookng.add(bookn);
				}
			}
			return bookng;
		}
	
}







