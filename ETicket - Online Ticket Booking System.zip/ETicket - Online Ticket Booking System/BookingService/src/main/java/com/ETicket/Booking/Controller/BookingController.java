package com.ETicket.Booking.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.ETicket.Booking.Model.Booking;


import com.ETicket.Booking.Model.Show;

import com.ETicket.Booking.Service.BookingService;

@RestController
public class BookingController {

	@Autowired
	private BookingService service;

	//To add show details by Admin
	
	@PostMapping(value = "/admin/addshow")
	public ResponseEntity<Show> addShow(@RequestBody Show show) {
		return new ResponseEntity<>(service.addShow(show), HttpStatus.OK);
	}
	
	// To view all show details by Admin/user

	@GetMapping(value = "/admin/user/Allshows")
	public ResponseEntity<List<Show>> getShows() {
		return new ResponseEntity<>(service.getAllShows(), HttpStatus.OK);
	}

	
	// To view all show details by Admin/user by showid
	
	@GetMapping(value = "/admin/user/getShowbyId/{showid}")
	
	public ResponseEntity<Show> getShowById(@PathVariable("showid") Integer showid) {
		return new ResponseEntity<>(service.getShow(showid), HttpStatus.OK);
	}

	// To view all show details by Admin/user by moviename
	
	@GetMapping(path = "/admin/user/getshow/{moviename}")
	public ResponseEntity<List<Show>> findShowByMoive(@PathVariable("moviename") String moviename) {
		return new ResponseEntity<>(service.findShowByMoive(moviename), HttpStatus.OK);
	}

	// To view all show details by Admin/user by theatrename
	
	@GetMapping(path = "/admin/user/getshowbytheatre/{theatrename}")
	public ResponseEntity<List<Show>> findShowByTheatre(@PathVariable("theatrename") String theatrename) {
		return new ResponseEntity<>(service.findShowByTheatre(theatrename), HttpStatus.OK);
	}

	// To update show details by Admin by showid
	
	@RequestMapping(method = RequestMethod.PUT, value = "/admin/updateshow/{showid}")
	public ResponseEntity<Show> updateDetails(@PathVariable("showid") Integer showid, @Valid @RequestBody Show show) {
		return new ResponseEntity<>(service.updateshowDetails(showid, show), HttpStatus.OK);
	}

	//To delete show details by Admin by showid
	
	@DeleteMapping(path = "/admin/show/{showid}")
	public ResponseEntity<Void> deleteShow(@PathVariable("showid") Integer showid) {
		service.deleteShow(showid);
		return new ResponseEntity<Void>(HttpStatus.OK);

	}

	//To add booking  by user
	
	@PostMapping(value = "/user/addbooking")
	public ResponseEntity<Booking> addBooking(@Valid @RequestBody Booking booking) {
		return new ResponseEntity<>(service.addBooking(booking), HttpStatus.OK);
	}

	//To get booking details by Admin 
	
	@GetMapping(value = "/admin/Allbooking")
	public ResponseEntity<List<Booking>> getBooking() {
		return new ResponseEntity<>(service.getBookings(), HttpStatus.OK);
	}

	//To get booking details by user 
	
	@GetMapping(value = "/admin/user/Allbooking/{userid}")
	public ResponseEntity<List<Booking>> getBookingbyuser(@PathVariable("userid") String userid) {
		return new ResponseEntity<>(service.getBookingsbyuser(userid), HttpStatus.OK);
	}

	//To get booking details by Admin for a period
	
	@GetMapping(path = "/admin/getbooking/{fromDate}/{toDate}")
	public ResponseEntity<List<Booking>> getBookings(@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) throws Throwable {
		return new ResponseEntity<>(service.getBookingsbytdate(fromDate, toDate), HttpStatus.OK);
	}

	//To cancel booking by user 
	
	@DeleteMapping(path = "/user/cancelbooking/{bookingid}")
	public ResponseEntity<Void> cancelBooking(@PathVariable("bookingid") Integer bookingid) {
		service.deleteBooking(bookingid);
		return new ResponseEntity<Void>(HttpStatus.OK);

	}

}