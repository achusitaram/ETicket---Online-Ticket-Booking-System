package com.ETicket.Booking.Model;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "booking_table", schema = "eticket")
public class Booking {

	@Id
	@Column(name = "bookingid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer bookingid;

	@OneToOne
	private UserModel user;

	@OneToOne
	private Show show;

	private String moviename;

	private String theatrename;
	private Date showdate;

	private Time showtime;

	private int nooftickets;

	private Float cost;

	private String status;

	public Booking() {
		super();

	}

	public Booking(Integer bookingid, UserModel user, Show show, String moviename, String theatrename, Date showdate,
			Time showtime, int nooftickets, Float cost, String status) {
		super();
		this.bookingid = bookingid;
		this.user = user;
		this.show = show;
		this.moviename = moviename;
		this.theatrename = theatrename;
		this.showdate = showdate;
		this.showtime = showtime;
		this.nooftickets = nooftickets;
		this.cost = cost;
		this.status = status;
	}

	public Integer getBookingid() {
		return bookingid;
	}

	public void setBookingid(Integer bookingid) {
		this.bookingid = bookingid;
	}

	public UserModel getUser() {
		return user;
	}

	public void setUser(UserModel user) {
		this.user = user;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public Date getShowdate() {
		return showdate;
	}

	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}

	public Time getShowtime() {
		return showtime;
	}

	public void setShowtime(Time showtime) {
		this.showtime = showtime;
	}

	public int getNooftickets() {
		return nooftickets;
	}

	public void setNooftickets(int nooftickets) {
		this.nooftickets = nooftickets;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}