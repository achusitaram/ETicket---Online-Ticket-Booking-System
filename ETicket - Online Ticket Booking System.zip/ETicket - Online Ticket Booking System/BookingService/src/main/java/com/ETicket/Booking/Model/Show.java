package com.ETicket.Booking.Model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "show_table", schema = "eticket")
public class Show {

	@Id
	@Column(name = "showid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Integer showid;

	@OneToOne
	private MovieModel movie;

	@OneToOne
	private TheatreModel theatre;

//	@JsonFormat(pattern="yyyy-MM-dd")
	private Date showdate;

	private Time showtime;

	private int seatsavailable;

	private float ticketcost;

	public Show() {
		super();
	}

	public Show(Integer showid, MovieModel movie, TheatreModel theatre, Date showdate, Time showtime,
			int seatsavailable, float ticketcost) {
		super();
		this.showid = showid;
		this.movie = movie;
		this.theatre = theatre;
		this.showdate = showdate;
		this.showtime = showtime;
		this.seatsavailable = seatsavailable;
		this.ticketcost = ticketcost;
	}

	public Integer getShowid() {
		return showid;
	}

	public void setShowid(Integer showid) {
		this.showid = showid;
	}

	public MovieModel getMovie() {
		return movie;
	}

	public void setMovie(MovieModel movie) {
		this.movie = movie;
	}

	public TheatreModel getTheatre() {
		return theatre;
	}

	public void setTheatre(TheatreModel theatre) {
		this.theatre = theatre;
	}
	@JsonFormat(pattern="yyyy-MM-dd")
	public Date getShowdate() {
		return showdate;
	}

	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}

	public Time getShowtime() {
		return showtime;
	}

	public void setShowtime(Time showtime) {
		this.showtime = showtime;
	}

	public int getSeatsavailable() {
		return seatsavailable;
	}

	public void setSeatsavailable(int seatsavailable) {
		this.seatsavailable = seatsavailable;
	}

	public float getTicketcost() {
		return ticketcost;
	}

	public void setTicketcost(float ticketcost) {
		this.ticketcost = ticketcost;
	}
	
}