package com.ETicket.Booking.Repository;




import org.springframework.data.repository.CrudRepository;

import com.ETicket.Booking.Model.Booking;

public interface BookingRepository extends CrudRepository<Booking,Integer> {




	

}
