package com.ETicket.Booking.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "theatre_table", schema = "eticket")
public class TheatreModel {
	@Id

	@Column(name = "theatrename")
	private String theatrename;
	@Column(name = "location")
	private String location;
	@Column(name = "seatingcapacity")
	private String seatingcapacity;

	public TheatreModel() {
		super();
	}

	public TheatreModel(String theatrename, String location, String seatingcapacity) {
		super();
		this.theatrename = theatrename;
		this.location = location;
		this.seatingcapacity = seatingcapacity;
	}

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSeatingcapacity() {
		return seatingcapacity;
	}

	public void setSeatingcapacity(String seatingcapacity) {
		this.seatingcapacity = seatingcapacity;
	}
}
