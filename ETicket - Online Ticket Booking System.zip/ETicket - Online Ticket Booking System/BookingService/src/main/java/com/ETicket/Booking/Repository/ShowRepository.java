package com.ETicket.Booking.Repository;


import org.springframework.data.repository.CrudRepository;

import com.ETicket.Booking.Model.Show;

public interface ShowRepository extends CrudRepository<Show,Integer> {

}
