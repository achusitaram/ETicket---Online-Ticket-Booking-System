package com.ETicket.Movie.Service;

import java.util.List;
import java.util.Optional;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ETicket.Movie.Model.MovieModel;
import com.ETicket.Movie.Repository.MovieRepository;

@Service
public class MovieService {

	@Autowired
	public MovieRepository mrep;

	public void addMovie(MovieModel mov) {
		mrep.save(mov);
	}

	public List<MovieModel> getAllmovies() {
		List<MovieModel> users = (List<MovieModel>) mrep.findAll();
		return users;
	}

	public MovieModel updateDetails(String moviename, MovieModel mov) {
		mov.setMoviename(moviename);
		return mrep.save(mov);
	}

	public void deletemovie(String moviename) {
		mrep.deleteById(moviename);

	}

	public Optional<MovieModel> findMovie(String moviename) {
		Optional<MovieModel> mov = mrep.findById(moviename);
		return mov;
	}

}
