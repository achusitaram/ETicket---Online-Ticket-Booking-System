package com.ETicket.Movie.Repository;


import org.springframework.stereotype.Repository;

import com.ETicket.Movie.Model.MovieModel;

import org.springframework.data.repository.CrudRepository;

	@Repository
	public interface MovieRepository extends CrudRepository<MovieModel, String> {

	
}
