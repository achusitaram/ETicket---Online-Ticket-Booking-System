package com.ETicket.Movie.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movie_table", schema = "eticket")
public class MovieModel {

	@Id
	@Column(name = "moviename")
	private String moviename;
	@Column(name = "language")
	private String language;
	@Column(name = "director")
	private String director;
	@Column(name = "rating")
	private int rating;
	
	public MovieModel() {
		
	}
	public MovieModel(String moviename, String language, String director, int rating) {
		
		this.moviename = moviename;
		this.language = language;
		this.director = director;
		this.rating = rating;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public int getRatting() {
		return rating;
	}
	public void setRatting(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "MovieBeans [moviename=" + moviename + ", language=" + language + ", director=" + director + ", rating="
				+ rating + "]";
	}
	
	
	
	
}
