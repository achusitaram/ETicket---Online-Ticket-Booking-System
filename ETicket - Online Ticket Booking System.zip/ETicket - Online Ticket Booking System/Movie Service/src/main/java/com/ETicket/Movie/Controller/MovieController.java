package com.ETicket.Movie.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ETicket.Movie.Model.MovieModel;
import com.ETicket.Movie.Service.MovieService;

@RestController
public class MovieController {

	@Autowired
	private MovieService mservice;

	// TO GET MOVIE DETAILS BY ADMIN/USERS
	@GetMapping("/admin/users/moviedetails")
	public List<MovieModel> getAllmovies() {
		return mservice.getAllmovies();
	}

	// TO ADD MOVIE DETAILS BY ADMIN
	@RequestMapping(method = RequestMethod.POST, value = "/admin/addMovie")
	public void addMovie(@RequestBody MovieModel mov) {
		mservice.addMovie(mov);
	}
	// TO UPDATE MOVIE DETAILS BY ADMIN

	@RequestMapping(method = RequestMethod.PUT, value = "/updatemovie/{moviename}")
	public ResponseEntity<MovieModel> updateDetails(@PathVariable("moviename") String moviename,
			@Valid @RequestBody MovieModel mov) {
		return new ResponseEntity<>(mservice.updateDetails(moviename, mov), HttpStatus.OK);
	}

	// TO FETCH DETAILS OF MOVIE BY MOVIENAME BY USERS/ADMIN
	@GetMapping(path = "/admin/users/getMovie/{moviename}")
	public Optional<MovieModel> MovieDetails(@PathVariable String id) {
		return mservice.findMovie(id);
	}

	// TO DELETE MOVIE BY MOVIE NAME BY ADMIN
	@DeleteMapping(path = "/admin/deletemovie/{id}")
	public void deletemovie(@PathVariable String id) {
		mservice.deletemovie(id);

	}

}
