package com.ETicket.Theatre.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ETicket.Theatre.Model.TheatreModel;
import com.ETicket.Theatre.Repository.TheatreRepository;


@Service
public class TheatreService {

	@Autowired
	public TheatreRepository trepo;
	
	
	public TheatreModel updateDetails(String theatrename,TheatreModel theatre) {
		theatre.setTheatrename(theatrename);
		return trepo.save(theatre);
	}

	public TheatreModel addTheatre( TheatreModel theatres) {
		return trepo.save(theatres);
	}
	public List<TheatreModel> getAllTheatre(){
		List<TheatreModel> theatres= (List<TheatreModel>) trepo.findAll();
		return theatres;
		
	}

	public void deletetheatre(String theatrename) {
		trepo.deleteById(theatrename);
		}

	public Optional<TheatreModel> findTheatre(String theatrename) {        
		Optional<TheatreModel> theatre= trepo.findById(theatrename);         
		return theatre;     
		}                                       

}
