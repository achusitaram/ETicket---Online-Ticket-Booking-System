package com.ETicket.Theatre.Repository;
import org.springframework.stereotype.Repository;

import com.ETicket.Theatre.Model.TheatreModel;

import org.springframework.data.repository.CrudRepository;

	@Repository
	public interface TheatreRepository extends CrudRepository<TheatreModel, String> {

	}

